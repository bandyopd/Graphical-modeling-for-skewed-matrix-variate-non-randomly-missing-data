# function to update the degree of freedom, nu
nu.update = function(gamma,nu,nu.step,nu.prior){

	# propose a new nu from random walk
	# Here we restrict nu between [2,40]	
	#nu.step = 1

	nu.prop = nu
	while(nu.prop==nu) nu.prop = max(2,min(nu+rnorm(1,sd=nu.step),40))

	logdens.prop = log(sapply(gamma,dgamma,nu.prop/2,rate=nu.prop/2))
	logdens.curr = log(sapply(gamma,dgamma,nu/2,rate=nu/2))

	#lograte.accept = sum(logdens.prop)+log(dgamma(nu.prop,nu.prior[1],rate=nu.prior[2]))-
	#	sum(logdens.curr)-log(dgamma(nu,nu.prior[1],rate=nu.prior[2]))
	lograte.accept = sum(logdens.prop)-sum(logdens.curr)

	if(log(runif(1)) < lograte.accept) return(nu.prop) else return(nu)


}