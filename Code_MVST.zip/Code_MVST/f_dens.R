f_dens = function(nu,n,s,lambda,a,b,c) {

w = a+nu*b*sqrt(c/n);
f = (n/2)*log(1-nu^2/n) - s*w - lambda*abs(w);

return(f)
}