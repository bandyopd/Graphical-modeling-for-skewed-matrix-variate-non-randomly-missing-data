# function to update missing intercept, a
a.update = function(c,ab.step,ybar,delta,missing.type,a,b,xi) { 
	
	a.prop = a+rnorm(1,sd=ab.step)
	tmp = sapply(alply(ybar,3), function(x) x%*%b)

	val.curr = a+tmp
	val.prop = a.prop+tmp

	if(missing.type=='probit') {
		F.curr = apply(val.curr,1:2,pnorm)
		F.prop = apply(val.prop,1:2,pnorm)
		}
	if(missing.type=='gev') {
		F.curr = apply(val.curr,1:2,pgev,xi)
		F.prop = apply(val.prop,1:2,pgev,xi)
		}

	lograte.accept = sum(log(F.prop^delta))+sum(log((1-F.prop)^(1-delta)))+log(dnorm(a.prop,sd=sqrt(c))) -
			sum(log(F.curr^delta))-sum(log((1-F.curr)^(1-delta)))-log(dnorm(a,sd=sqrt(c))) 

	if(log(runif(1)) < lograte.accept) return(a.prop) else return(a)
	
}