# funcion to update tau2, the latent scale variable for graphical lasso
# used only for cross-validation test

tau2.update.cv = function(S, lambda, Omega) {

    tau2_new = diag(1,S);

    for(i in 1:(S-1))   {
        for(j in (i+1):S) {

            lambda_prime = lambda^2;  
            mu_prime = min(abs(lambda/Omega[i,j]),10^12);

            tau2_new[i,j] = 1/rinvgauss(1,mu_prime, lambda_prime);   
	      tau2_new[j,i] = tau2_new[i,j]

        }
    }
    return(tau2_new)
}