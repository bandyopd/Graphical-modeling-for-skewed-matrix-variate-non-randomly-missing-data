# function to calculate the log density of multivariate skew-t distribution
log.dmvst = function(ynew.filled,X.new,W,u,alpha,beta,V,Omega,eta,nu) {

   library(plyr)   # split 3D array to list of matrices
   library(expm)   # calculate square root of a matrix 
   library(fExtremes)	# sample from generalized extreme value distribution
   library(mvtnorm)	# calculate multivariate t distribution

S=nrow(ynew.filled); J=ncol(ynew.filled); N.new=dim(ynew.filled)[3];

mu = replicate(N.new,u) + replicate(N.new,W%*%alpha) + aperm(replicate(S,t(beta)%*%X.new),c(3,1,2))
A = alply(ynew.filled-mu,3);

Sigma = solve(Omega)
SIGMA = kronecker(V,Sigma+diag(eta^2))

tmp = diag(eta)%*%solve(Sigma+diag(eta^2))

tmp2 = solve(Sigma+diag(eta^2))
Vinv = solve(V)
tmp3 = sapply(A, function(x) sum(diag(t(x)%*%tmp2%*%x%*%Vinv)) )

cons.new = sqrt(nu+J*S)/sqrt(nu+tmp3)

#tmp3 = sum(diag(t(ynew.filled-mu)%*%solve(Sigma+diag(eta^2))%*%(ynew.filled-mu)%*%solve(V)))
#Z = c(tmp%*%(ynew.filled-mu)%*%sqrtm(solve(V)))*sqrt(nu+J*S)/sqrt(nu+tmp2)

Z = mapply(function(x1,x2) c(tmp%*%x1%*%sqrtm(Vinv))*x2, A, cons.new, SIMPLIFY=FALSE)
DELTA = diag(1,J*S)-kronecker(diag(1,J),tmp%*%diag(eta))

log.dens = sapply(A,function(x) dmvt(c(x),sigma=SIGMA,df=nu))+sapply(Z, function(x) max(-800,log(pmvt(upper=x,sigma=DELTA,df=nu+J*S))))
return(log.dens)


}