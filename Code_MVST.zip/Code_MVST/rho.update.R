# function to update the probability of an edge existance, rho
rho.update = function(S,Omega,rho.prior){

	adj = (abs(Omega) > 0.0001)*1

	rho = matrix(0,S,S)
	rho[upper.tri(rho)] = sapply(adj[upper.tri(adj)], function(x) rbeta(1,rho.prior[1]+x,rho.prior[2]+1-x))

	return(rho)

}