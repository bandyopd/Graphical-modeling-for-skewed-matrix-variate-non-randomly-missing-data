# function to update precision matrix, Omega, for cross validation
# no shrinkage on diagonal elements for convergence reason
# no selection with rho prior on off-diagonal elements for computation speed consideration

Omega.update.cv = function(N,J,S,Omega,Tau,lambda,tau2) {

    n = N*J

    for(j in 1:S) {
        
        ind.minus = setdiff(1:S,j);
        C = qr.solve((Tau[j,j]+lambda) * qr.solve(Omega[ind.minus,ind.minus]) + diag(1/tau2[j,ind.minus]));
        
        # sigmajj.inv = max(0.0001,rgamma(1,n/2+1,scale=2/(Tau[j,j]+lambda)));
	  sigmajj = rgig(1,lambda=-n/2,chi=Tau[j,j],psi=2);

        tmp = rnorm(S-1)%*%chol(C)-Tau[j,ind.minus] %*% t(C);
        
        Omega[ind.minus,j] = tmp;
        Omega[j,ind.minus] = tmp;
        Omega[j,j] = 1/sigmajj + tmp %*% qr.solve(Omega[ind.minus,ind.minus]) %*% t(tmp);
    }

    return(Omega)
}