# function to update latent degree of freedom parameters, gamma
gamma.update = function(N,S,J,nu,z,Omega,Vinv,A,dzv) {

	c.gamma = nu/2+S*J

	#tmp = A-dzv
	#tmp2 = mapply(function(x1,x2) t(x1)%*%x1+Vinv%*%t(x2)%*%Omega%*%x2, alply(z,3), alply(tmp,3), SIMPLIFY=FALSE)
	#d.gamma = nu/2+sapply(tmp2, function(x) sum(diag(x))/2 )

	d.gamma = foreach(i=1:N,.combine='c') %dopar% {
		nu/2 + sum(diag(t(z[,,i])%*%z[,,i]+Vinv%*%t(A[,,i]-dzv[,,i])%*%Omega%*%(A[,,i]-dzv[,,i])))/2
		}

	return(sapply(d.gamma,function(x) rgamma(1,c.gamma,rate=x)))
}
