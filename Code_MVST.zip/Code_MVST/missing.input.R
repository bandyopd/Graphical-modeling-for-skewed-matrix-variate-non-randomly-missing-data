# function to input missing values for (CV) predictive distribution analysis

missing.input <- function(y.new,delta.new,mvst.para,miss.para,missing.type='probit',initials,runs=500,burn=100,thin=1,update=10,ncore=1) {

   #INPUTS:
   #y.new = Ssites x Jresponses x Nnew matrix of responses to input missing values
   #delta.new = Tteeth x Nnew matrix of binary teeth missingness indicators
   #mvst.para = parameters for multivariate skew-t distribution
   #miss.para = parameters for missing mechanism
   #missing.type:  either 'probit' or 'gev' for nonrandom missing mechanism


   #MODEL:
   #yi = MVST(u+W*alpha+Xi*beta, Omega^-1, V, eta, nu)
   #P(delta[t,i]=1) = F(a+yi'Ctb),  F: cdf of standard normal or gev distribution
   #Omega ~ Graphical lasso selection prior(lambda,rho)



   #Load required libraries:
   library(plyr)   # split 3D array to list of matrices
   library(expm)   # calculate square root of a matrix 
   library(fExtremes)	# sample from generalized extreme value distribution
   library(mvtnorm)	# calculate multivariate normal distribution
   library(abind)
   library(TTmoment)	# efficiently sample from truncated multivariate t distribution

   library(doParallel)
   registerDoParallel(cores=ncore)


   #missing.type='probit'; runs=1000; burn=0; thin=1; update=1;  nu=40;


   if(!missing.type %in% c('probit','gev')) stop("missing.type should be either 'probit' or 'gev'")


   #Priors & Constant values

   S = nrow(y.new); J = ncol(y.new); N = dim(y.new)[3]; T = nrow(delta.new);



   yMISS = is.na(y.new); 						# binary matrix indicating y missingness

   ST.match = rep(1:T,each=S/T) 				# vector matching spatial locations to teeth



   #Store MCMC output: (not including z,gamma, and rho)

   ymis.save = array(NA,c(runs,sum(yMISS)));  colnames(ymis.save) = 1:sum(yMISS)
  

   
   #INITIAL VALUES:

   #for(j in 1:J) y.new[,j,][is.na(y.new[,j,])] = mean(na.omit(as.vector(y.new[,j,]))) 
   #z = array(0,c(S,J,N))
   #gamma = rep(1,N)

   y.new[is.na(y.new)] = initials$ymis
   z = initials$z
   gamma = initials$gamma


   #PARAMETER VALUES
   a = miss.para[1]; b = miss.para[2:(J+1)]; xi = ifelse(missing.type=='gev',miss.para[J+2],NA);

   mu = mvst.para$mu; eta = mvst.para$eta; V = mvst.para$V; Omega = mvst.para$Omega; nu=mvst.para$nu

   U = mu; Vinv = solve(V); sqrtV = sqrtm(V);




   # MCMC interations for collecting data
   for(iter in 1:(runs*thin+burn)) { 

	## UPDATE MISSING OBSERVATIONS

if(TRUE)
	y.new[yMISS] = ymis.update(N,J,y.new,yMISS,delta,ST.match,missing.type,a,b,xi,U,V,Omega,gamma)	#debugged

	A = y.new - mu; 


	## UPDATE MVST PARAMETERS


if(TRUE)
while(TRUE) {	
	z = try(z.update.old(N,S,J,nu,A,Vinv,Omega,eta),TRUE)					#debugged
	if(any(is.na(z))) cat('NA of z generated at iteration', iter,'\n') else
	if(inherits(z,"try-error")) cat('Error in z sampling at iteration', iter,'\n') else break
	}

	dzv = sapply(alply(z,3),function(x) diag(eta)%*%x%*% sqrtV, simplify='array')
	U = mu+dzv;


if(TRUE)
	gamma = gamma.update(N,S,J,nu,z,Omega,Vinv,A,dzv)		#debugged



      ##Keep track of MCMC output:
      if(iter>burn & (iter-burn)%%thin==0){
		ii = (iter-burn)/thin

		ymis.save[ii,] = y.new[yMISS]


      }
	if(iter %% update ==0) cat(iter,'\n')


   }  # end of MCMC interaction


   return(ymis.save)

}	# end of function


