# function to update missing skewness, xi, for GEV model
xi.update = function(xi.step,ybar,delta,a,b,xi) {

    	#xi.step = 0.1
	
	xi.prop = xi
	while(xi.prop == xi) xi.prop = max(-1,min(xi+rnorm(1,sd=xi.step),1))

	val = a + sapply(alply(ybar,3), function(x) x%*%b)

	F.curr = apply(val,1:2,pgev,xi)
	F.prop = apply(val,1:2,pgev,xi.prop)


	lograte.accept = sum(log(F.prop^delta))+sum(log((1-F.prop)^(1-delta)))-
			sum(log(F.curr^delta))-sum(log((1-F.curr)^(1-delta)))

	if(log(runif(1)) < lograte.accept) return(xi.prop) else return(xi)

	
}