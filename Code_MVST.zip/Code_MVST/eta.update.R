# function to update skewness parameter, eta
eta.update = function(N,S,Psi,gamma,z,Omega,A,Vinv){


	#tmp = mapply(function(x1,x2) x1*diag(x2)%*%Omega%*%diag(x2), rep(gamma,each=J), alply(z,2:3), SIMPLIFY='array')
	tmp = foreach(i=1:N,.combine='+') %:% foreach(j=1:dim(z)[2],.combine='+') %dopar%  {gamma[i]*diag(z[,j,i])%*%Omega%*%diag(z[,j,i])}
	SIGMA.eta = solve(solve(Psi)+tmp)


	tmp0 = sqrtm(Vinv)
	A_star = sapply(alply(A,3),function(x) x%*%tmp0,simplify='array')

	#tmp2 = mapply(function(x1,x2,x3) x1*diag(x2)%*%Omega%*%x3, rep(gamma,each=J),alply(z,2:3),alply(A_star,2:3),SIMPLIFY='array')
	tmp2 = foreach(i=1:N,.combine='+') %:% foreach(j=1:dim(z)[2],.combine='+') %dopar% {gamma[i]*diag(z[,j,i])%*%Omega%*%A_star[,j,i]}
	mean.eta = SIGMA.eta %*% tmp2

	return(c(rnorm(S)%*%chol(SIGMA.eta) + t(mean.eta)))

}