# function to update glasso parameter, lambda
lambda.update.cv = function(Omega, lambda.prior){

    tmp = upper.tri(Omega)
    lambda = rgamma(1,lambda.prior[1]+sum(tmp), rate=lambda.prior[2]+sum(abs(Omega[tmp])));

    return(lambda)
}