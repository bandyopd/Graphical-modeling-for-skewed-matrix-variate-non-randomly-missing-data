# function to update spatial regression coefficients, alpha
alpha.update = function(c,q,S,J,N,gamma,Vinv,Omega,y,u,W,xbeta,dzv) {  

	
	SIGMA.alpha = solve(c*diag(1,q*J)+ sum(gamma)*kronecker(Vinv,t(W)%*%Omega%*%W))

	#tmp = y - replicate(N,u) - aperm(replicate(S,xbeta),c(3,1,2)) - dzv
	#tmp2 = sapply(alply(tmp,3), function(x) t(W)%*%Omega%*%x%*%Vinv)

	tmp2 = foreach(i = 1:N, .combine='+') %dopar% {
		c(t(W)%*%Omega%*%(y[,,i]-u-matrix(xbeta[,i],S,J,byrow=T)-dzv[,,i])%*%Vinv)*gamma[i]
	}	

	mean.alpha = SIGMA.alpha %*% tmp2

	return(matrix(rnorm(q*J)%*%chol(SIGMA.alpha) + t(mean.alpha),q,J))

}