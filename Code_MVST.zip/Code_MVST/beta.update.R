# function to update clinical regression coefficients, beta
beta.update = function(c,p,S,J,N,gamma,Vinv,Omega,y,u,walpha,XX,dzv) {  

	#tmp0 = sapply(alply(XX,3),function(x) t(x)%*%Omega%*%x,simplify='array') * array(rep(gamma,each=p*p),c(p,p,length(gamma)))
	#SIGMA.beta = solve(c*diag(1,p*J)+ kronecker(Vinv,apply(tmp0,1:2,sum)))

	tmp0 = foreach(i = 1:N,.combine='+') %dopar% {
		t(XX[,,i])%*%Omega%*%XX[,,i]*gamma[i]
	}
	SIGMA.beta = solve(c*diag(1,p*J)+ kronecker(Vinv,tmp0))

	
	#tmp = y - replicate(N,u) - replicate(N,walpha) - dzv
	#tmp2 = mapply(function(x1,x2) t(x1)%*%Omega%*%x2%*%Vinv, alply(XX,3), alply(tmp,3))

	tmp2 = foreach(i = 1:N,.combine='+') %dopar% {
		c(t(XX[,,i])%*%Omega%*%(y[,,i]-u-walpha-dzv[,,i])%*%Vinv)*gamma[i]
	}
	mean.beta = SIGMA.beta %*% tmp2

	return(matrix(rnorm(p*J)%*%chol(SIGMA.beta) + t(mean.beta),p,J))

}