# function to update latent continuous variables, z
# sample (S by 1) vector of z_ij at one time
# from the truncated multivariate T distribution marginalized over gamma parameters
# sample j=1 from marginal truncated T and sample j=2 from conditional (on j=1) truncated T
# Note this algorithm ONLY WROKS FOR J=2
z.update = function(N,S,J,nu,A,Vinv,Omega,eta) {
    
    if(J!=2) stop("this z.update function only works for J=2")
    
    z_new = array(NA,c(S,J,N))
    
    D_eta = diag(eta)
    
    tmp0 = sqrtm(Vinv)
    A_star = sapply(alply(A,3), function(x) x%*%tmp0, simplify=FALSE )
    
    
    Delta.z = solve(diag(1,S)+D_eta%*%Omega%*%D_eta)
    
    tmp1 = Delta.z%*%D_eta%*%Omega
    mean.zij = sapply(A_star, function(x) tmp1%*%x,simplify='array')
    
    
    tmp = solve(solve(Omega)+D_eta^2)
    cons.zi = (sapply(A_star, function(x) sum(diag(t(x) %*% tmp %*% x))) + nu)/(J*S+nu)
    
    
    # SIGMA.zi = sapply(cons.zi, function(x)  x * Delta.z, simplify=FALSE)
    
    nu.z = nu+S*J
    
    S.half = S/2
    Delta.z.half1.inverse = solve(Delta.z[1:S.half,1:S.half])
    
    # sample j=1 from marginal truncated T
    j = 1
    
    #z_new[,j,] = mapply(function(x1,x2) TT.GS(1,mu=x1,S=x2,nu=nu.z,lower=rep(0,S)),alply(mean.zij[,j,],2),SIGMA.zi)
    
    #partition z to two S/2 blocks for each z, and sample each block separately
    z_new[,j,] = foreach(i=1:N,.combine='cbind',.export='TT.GS') %dopar% {
        mean.tmp1 = mean.zij[1:S.half,j,i]
        S.tmp1 = cons.zi[i]*Delta.z[1:S.half,1:S.half]
        z_new.tmp1 = c(TT.GS(1,mu=mean.tmp1,S=S.tmp1,nu=nu.z,lower=rep(0,S.half)))
        
        S.tmp2 = cons.zi[i]*(Delta.z[-(1:S.half),-(1:S.half)] - 
                 Delta.z[-(1:S.half),(1:S.half)]%*% Delta.z.half1.inverse %*%Delta.z[(1:S.half),-(1:S.half)])
        S.tmp2 = c(t(z_new.tmp1-mean.tmp1)%*%(Delta.z.half1.inverse/cons.zi[i])%*%(z_new.tmp1-mean.tmp1)+nu.z)/(nu.z+S.half)*S.tmp2
        mean.tmp2 = mean.zij[-(1:S.half),j,i] + 
                 Delta.z[-(1:S.half),(1:S.half)]%*% Delta.z.half1.inverse %*%(z_new.tmp1-mean.tmp1)
        z_new.tmp2 = c(TT.GS(1,mu=mean.tmp2,S=S.tmp2,nu=nu.z+S.half,lower=rep(0,S.half)))
        
        c(z_new.tmp1,z_new.tmp2)
    }
    
    
    # sample j=2 from conditional truncated T # this only works for J=2
    j = 2   
    
    nu.zj = nu.z+S
    mean.zj = mean.zij[,j,]
    
    
    # cons.zj = mapply(function(x1,x2,x3) (t(x1-x2) %*% solve(x3) %*% (x1-x2) + nu.z)/nu.zj, alply(z_new[,-j,],2), alply(mean.zij[,-j,],2), SIGMA.zi)
   
    # SIGMA.zj = sapply(cons.zi*cons.zj, function(x) x*Delta.z, simplify=FALSE)
   
    # z_new[,j,] = mapply(function(x1,x2) TT.GS(1,mu=x1,S=x2,nu=nu.zj,lower=rep(0,S)),alply(mean.zj,2),SIGMA.zj)
    # z_new[,j,] = foreach(i=1:N,.combine='cbind',.export='TT.GS') %dopar% c(TT.GS(1,mu=mean.zj[,i],S=SIGMA.zj[[i]],nu=nu.zj,lower=rep(0,S)))
   
     z_new[,j,] = foreach(i=1:N,.combine='cbind',.export='TT.GS') %dopar% {
        cons.zj = c(t(z_new[,-j,i]-mean.zij[,-j,i]) %*% solve(cons.zi[i]*Delta.z) %*% (z_new[,-j,i]-mean.zij[,-j,i]) + nu.z)/nu.zj
        
        # c(TT.GS(1,mu=mean.zj[,i],S=cons.zj*cons.zi[i]*Delta.z,nu=nu.zj,lower=rep(0,S)))
        
        mean.tmp1 = mean.zj[1:S.half,i]
        S.tmp1 = cons.zj*cons.zi[i]*Delta.z[1:S.half,1:S.half]
        z_new.tmp1 = c(TT.GS(1,mu=mean.tmp1,S=S.tmp1,nu=nu.zj,lower=rep(0,S.half)))
        
        S.tmp2 = cons.zj*cons.zi[i]*(Delta.z[-(1:S.half),-(1:S.half)] - 
                                 Delta.z[-(1:S.half),(1:S.half)]%*% Delta.z.half1.inverse %*%Delta.z[(1:S.half),-(1:S.half)])
        S.tmp2 = c(t(z_new.tmp1-mean.tmp1)%*%(Delta.z.half1.inverse/cons.zj/cons.zi[i])%*%(z_new.tmp1-mean.tmp1)+nu.zj)/(nu.zj+S.half)*S.tmp2
        mean.tmp2 = mean.zj[-(1:S.half),i] + 
            Delta.z[-(1:S.half),(1:S.half)]%*% Delta.z.half1.inverse %*%(z_new.tmp1-mean.tmp1)
        z_new.tmp2 = c(TT.GS(1,mu=mean.tmp2,S=S.tmp2,nu=nu.zj+S.half,lower=rep(0,S.half)))
        
        c(z_new.tmp1,z_new.tmp2)
        
    }
    
    
    return(z_new)
    
}