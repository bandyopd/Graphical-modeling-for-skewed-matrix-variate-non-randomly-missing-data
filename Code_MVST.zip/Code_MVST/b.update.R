# function to update missing coefficients, b
b.update = function(c,ab.step,ybar,delta,missing.type,a,b,xi) {		

   for(i in 1:length(b)) {
	
      b.prop = b
	b.prop[i] = b[i]+rnorm(1,sd=ab.step)

	val.curr = a + sapply(alply(ybar,3), function(x) x%*%b)
	val.prop = a + sapply(alply(ybar,3), function(x) x%*%b.prop)

	if(missing.type=='probit') {
		F.curr = apply(val.curr,1:2,pnorm)
		F.prop = apply(val.prop,1:2,pnorm)
		}
	if(missing.type=='gev') {
		F.curr = apply(val.curr,1:2,pgev,xi)
		F.prop = apply(val.prop,1:2,pgev,xi)
		}

	lograte.accept = sum(log(F.prop^delta))+sum(log((1-F.prop)^(1-delta)))+log(dnorm(b.prop[i],sd=sqrt(c))) -
			sum(log(F.curr^delta))-sum(log((1-F.curr)^(1-delta)))-log(dnorm(b[i],sd=sqrt(c))) 

	if(log(runif(1)) < lograte.accept) b[i] = b.prop[i]

   }  # end of loop of length b

   return(b)
	
}