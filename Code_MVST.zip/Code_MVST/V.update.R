# function to udpate the across-response covariance, V
V.update = function(N,S,J,V,A,eta,z,gamma,Omega,V.step){

   #V.step = 0.05

   if(J != 2) stop('Only works for J=2 at current stage')
   for(i in 1:2) {

	# propose new value from normal random walk
	# Here we limit v22 to [0.3,3] (not too different from v11)
	V.prop = V
	if(i==1) {
		while(V.prop[2,2]==V[2,2]) V.prop[2,2] = max(max(0.3,V[1,2]^2+0.001),min(V[2,2]+rnorm(1,sd=V.step),3)) 
	} else while(V.prop[1,2]==V[1,2]) {
		V.prop[1,2] = max(-sqrt(V[2,2])+0.001, min(V[1,2]+rnorm(1,sd=V.step), sqrt(V[2,2])-0.001))
		V.prop[2,1] = V.prop[1,2]
		}


	Vinv.sqrt = sqrtm(solve(V)); Vprop.inv.sqrt = sqrtm(solve(V.prop));
	val.curr = sapply(alply(A,3),function(x) x%*%Vinv.sqrt,simplify='array')
	val.prop = sapply(alply(A,3),function(x) x%*%Vprop.inv.sqrt,simplify='array')

	mean.val = sapply(alply(z,3),function(x) diag(eta)%*%x, simplify='array')
	sigma.val = solve(Omega)

	#logdens.curr = mapply(function(x1,x2,x3) dmvnorm(sqrt(x3)*(x1-x2),sigma=sigma.val,log=TRUE), alply(val.curr,2:3),alply(mean.val,2:3),rep(gamma,each=J)) 
	#logdens.prop = mapply(function(x1,x2,x3) dmvnorm(sqrt(x3)*(x1-x2),sigma=sigma.val,log=TRUE), alply(val.prop,2:3),alply(mean.val,2:3),rep(gamma,each=J)) 

	logdens.curr = foreach(i=1:N,.combine='c',.export=c('alply','dmvnorm')) %dopar% {mapply(function(x1,x2) dmvnorm(gamma[i]^.5*(x1-x2),sigma=sigma.val,log=TRUE), 
			alply(val.curr[,,i],2),alply(mean.val[,,i],2)) }
	logdens.prop = foreach(i=1:N,.combine='c',.export=c('alply','dmvnorm')) %dopar% {mapply(function(x1,x2) dmvnorm(gamma[i]^.5*(x1-x2),sigma=sigma.val,log=TRUE), 
			alply(val.prop[,,i],2),alply(mean.val[,,i],2)) }

	lograte.accept = sum(logdens.prop)- N*S*log(det(V.prop))/2 - (sum(logdens.curr)- N*S*log(det(V))/2)
	if(log(runif(1)) < lograte.accept) V = V.prop

   }  # end of loop for two V components

   return(V)

}