# function to update regression intercept, u
u.update = function(c,S,J,N,gamma,Vinv,Omega,y,walpha,xbeta,dzv) {	

	
	SIGMA.u = solve(c*diag(1,S*J)+ sum(gamma)*kronecker(Vinv,Omega))
	
	#tmp = y - replicate(N,walpha) - aperm(replicate(S,xbeta),c(3,1,2)) - dzv
	#tmp2 = sapply(alply(tmp,3), function(x) Omega%*%x%*%Vinv)
	#mean.u = SIGMA.u %*% rowSums(tmp2 %*% diag(gamma))

	tmp2 = foreach(i=1:N,.combine='+') %dopar% {
		c(Omega%*%(y[,,i]-walpha-matrix(xbeta[,i],S,J,byrow=T)-dzv[,,i])%*%Vinv)*gamma[i]
	}
	mean.u = SIGMA.u %*% tmp2

	return(matrix(rnorm(S*J)%*%chol(SIGMA.u) + c(mean.u),S,J))

}