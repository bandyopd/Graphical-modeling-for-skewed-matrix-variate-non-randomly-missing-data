# function to update precision matrix, Omega
# no shrinkage prior put on the diagonal elements
Omega.update = function(N,J,S,Omega,Tau,lambda,rho) {

	n = N*J
	
	# Update diagonal elements of Omega
	for(i in 1:S) {
		reorder = c(setdiff(1:S,i),i)
		Omega_reorder = Omega[reorder,reorder]

		R = chol(Omega_reorder)
		c0 = sum(R[1:(S-1),S]^2)

		rate_post = Tau[i,i]/2			# change from previous version
		Omega[i,i] = max(0.0001, c0+rgamma(1,n/2,rate=rate_post))   # set lower bound at 0.0001
		#sigmaii = rgig(1,lambda=-n/2,chi=2*rate_post,psi=2)
		#Omega[i,i] = max(0.0001, c0+1/sigmaii) 
	}

	
    	# Update off-diagonal elements of Omega
    	for(i in 1:(S-1))    
	   for(j in (i+1):S){
		reorder = c(setdiff(1:S,c(i,j)),i,j);
		Omega_reorder = Omega[reorder,reorder]
		
		gam = Tau[i,j]
		R = chol(Omega_reorder)
		a0 = sum(R[1:(S-2),S-1]*R[1:(S-2),S])
		b0 = R[S-1,S-1]
		c0 = R[S-1,S]^2+R[S,S]^2

		boundary = -a0/(b0*sqrt(c0/n))

		# calculate modes and standard deviations of the approximate normals

		delta0 = c((gam-lambda)*b0*sqrt(c0/n),(gam+lambda)*b0*sqrt(c0/n));
		nu_mode = (n - sqrt(4*n*delta0^2+n^2))/(2*delta0);
		nu_sigma =  (1-nu_mode^2/n)^2/(1+nu_mode^2/n)
		f_nu_mode = f_dens(nu_mode,n,Tau[i,j],lambda,a0,b0,c0);

		# generate a sample of nu from proposal distributions (of three mixtures)
		# calculate the posterior density (p_star) and proposal density (q_star)
		# the same constants in the two densities are cancelled out 
        
		if(boundary >= sqrt(n)) {
            
            	nu_star = rtnorm(1, mean=nu_mode[1], sd=nu_sigma[1]^.5, lower=-sqrt(n), upper=sqrt(n));
            	p_star = f_dens(nu_star,n,Tau[i,j],lambda,a0,b0,c0);
            	q_star = log(2*pi)/2+log(nu_sigma[1])/2+f_nu_mode[1]+dnorm(nu_star,nu_mode[1],nu_sigma[1]^.5,log=TRUE);
                
	      }    else if(boundary <= -sqrt(n)) {

			nu_star = rtnorm(1, mean=nu_mode[2], sd=nu_sigma[2]^.5, lower=-sqrt(n), upper=sqrt(n));
			p_star = f_dens(nu_star,n,Tau[i,j],lambda,a0,b0,c0);
			q_star = log(2*pi)/2+log(nu_sigma[2])/2+f_nu_mode[2]+dnorm(nu_star,nu_mode[2],nu_sigma[2]^.5,log=TRUE);             
           
        	}    else {

			p_ij = rho[i,j]

			w1 = log(nu_sigma[1])/2+f_nu_mode[1]+pnorm(boundary,nu_mode[1],nu_sigma[1]^.5,log.p=TRUE); #mixture 1: < boundary
			w2 = log(nu_sigma[2])/2+f_nu_mode[2]+pnorm(nu_mode[2],boundary,nu_sigma[2]^.5,log.p=TRUE); #mixture 2: > boundary
                  w3 = log(1-p_ij)+n/2*log(1-boundary^2/n)-log(p_ij)-log(lambda/2*sqrt(2*pi)); #mixture 3: = boundary

                  w = exp(c(w1,w2,w3)-max(w1,w2,w3));  
                  #if(any(w==Inf)) mix=which(w==Inf) else 
			mix = sample(1:3, 1, replace=TRUE, prob = w)
             
                  if(mix==3) {
                  	nu_star = boundary;
                        p_star = 1;
                        q_star = 1;
            
                  } else {
				if(mix==1) {
					nu_star = rtnorm(1,mean=nu_mode[1],sd=nu_sigma[1]^.5,lower=-sqrt(n),upper=boundary) 
                  	} else {
					nu_star = rtnorm(1,mean=nu_mode[2],sd=nu_sigma[2]^.5,lower=boundary,upper=sqrt(n))
				}
				p_star = f_dens(nu_star,n,Tau[i,j],lambda,a0,b0,c0);
                        q_star = log(2*pi)/2+log(nu_sigma[mix])/2+f_nu_mode[mix]+dnorm(nu_star,nu_mode[mix],nu_sigma[mix]^.5,log=TRUE);
            
			}
                    
		}


        	# calculate the posterior density (p_star) and proposal density (q_star) of the current value

        	nu_crt = sqrt(n)*(Omega[i,j]-a0)/(b0*sqrt(c0));
        
        	if( abs(nu_crt-boundary)<0.0001 )   {      # nu_crt belongs to mixture 3
            	p_crt = 1;
            	q_crt = 1;
        	} else {
            	mix_crt = (nu_crt>boundary)+1; # nu_crt belongs to mixture 1, or 2;

            	p_crt = f_dens(nu_crt,n,Tau[i,j],lambda,a0,b0,c0);
            	q_crt = log(2*pi)/2+log(nu_sigma[mix_crt])/2+f_nu_mode[mix_crt]+
					dnorm(nu_crt,nu_mode[mix_crt],nu_sigma[mix_crt]^.5,log=TRUE);
        	}


		# calculate acceptance rate alpha

		lograte.accept = p_star-q_star+q_crt-p_crt

	      if( log(runif(1)) < lograte.accept ) {
            	Omega[i,j] = b0*sqrt(c0/n)*nu_star+a0;
            	Omega[j,i] = Omega[i,j];
        	}
        
        
	}   # end of loop j=i+1:q, i=1:q-1


	return(Omega*(abs(Omega)>=0.0001))
	
}