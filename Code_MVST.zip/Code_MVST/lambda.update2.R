# function to update glasso parameter, lambda
lambda.update = function(Omega,lambda.prior) {

	adj = (abs(Omega-diag(diag(Omega))) > 0.0001)*1
	nonzeros = sum(adj)/2
	return(rgamma(1,lambda.prior[1]+nonzeros, rate=lambda.prior[2]+sum(abs(Omega[upper.tri(Omega)])) ))


}