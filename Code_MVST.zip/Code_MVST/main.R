#This file contains R code to perform MCMC sampling for 
#the matrix-variate skew-t model with two continuous responses with infomative 
#missingness.  An example using simulated data is given below.


mvst.info.miss <- function(y,delta,X,W=NULL,missing.type='probit',nu=40,runs=5000,burn=1000,thin=1,update=10,priors=NULL,initials=NULL,ncore=1) {

   #INPUTS:
   #y = Ssites x Jresponses x Nsubs matrix of responses
   #delta = Tteeth x Nsubs matrix of missingness
   #X = p x Nsubs matrix of subject-level covariates (no intercept)
   #W = Ssites x q matrix of spatial-level covariates
   #missing.type:  either 'probit' or 'gev' for nonrandom missing mechanism
   #nu: degree-of-freedom parameter for the matrix-variate skew-t distribution
   #runs = number of MCMC samples
   #burn = number to discard as burn-in
   #thin = number of iterations to skip before collecting the next posterior sample
   #update = how often to display current iteration
   #priors: LIST of prior hyperparameters
   #initials: LIST of initial values for the hyperparameters
   #ncore: number of cores for parallel computing

   #MODEL:
   #yi = MVST(u+W*alpha+Xi*beta, Omega^-1, V, eta, nu)
   #P(delta[t,i]=1) = F(a+yi'Ctb),  F: cdf of standard normal or gev distribution
   #Omega ~ Graphical lasso selection prior(lambda,rho)



   #Load required libraries:
   library(plyr)   # split 3D array to list of matrices
   library(expm)   # calculate square root of a matrix 
   library(TTmoment)	# efficiently sample from truncated multivariate t distribution
   library(msm)		# sample from truncated normal distribution
   library(fExtremes)	# sample from generalized extreme value distribution
   library(GIGrvg)	# sample from generalized inverse gaussian distribution
   library(statmod)	# sample form inverse gaussian distribution
   library(abind)

   library(doParallel)
   registerDoParallel(cores=ncore)


   #missing.type='probit'; runs=200; burn=0; thin=1; update=1; priors=NULL; #initials=NULL; nu=40;
   #y = y.org


   if(!missing.type %in% c('probit','gev')) stop("missing.type should be either 'probit' or 'gev'")


   #Priors & Constant values

   S = nrow(y); J = ncol(y); N = dim(y)[3]; T = nrow(delta);
   p = nrow(X); 
   if(is.null(W)) q=0 else q = ncol(W);

   c = ifelse(is.null(priors$c),100,priors$ab.var)  					# variance of intercept/coefficients, 100 by default
   ab.step = ifelse(is.null(priors$ab.step), 0.05 ,priors$ab.step)			# step size of MH sampler for a & b, 0.1 by default
   xi.step = ifelse(is.null(priors$xi.step), 0.01 ,priors$xi.step)
   nu.step = ifelse(is.null(priors$nu.step),   1 ,priors$nu.step)
   V.step = ifelse(is.null(priors$V.step),   0.005 ,priors$V.step)
   Psi = ifelse(matrix(is.null(priors$Psi),S,S), diag(1,S),priors$Psi)			# covariance of normal prior for eta (skewness)
   nu.prior = ifelse(rep(is.null(priors$nu),2),c(1,0.001),priors$nu)			# gamma prior (shape=1,rate=0.1 by default) for nu (df of t-dist)
   lambda.prior = ifelse(rep(is.null(priors$lambda),2),c(1,0.01),priors$lambda)	# gamma prior (shape=1,rate=0.1 by default) for lambda (glasso)
   rho.prior = ifelse(rep(is.null(priors$rho),2),c(1,1),priors$rho)			# beta prior (1,1) for rho (edge selection)


   yMISS = is.na(y); 						# binary matrix indicating y missingness
   XX = aperm(replicate(S,X,simplify='array'),c(3,1,2))
   ST.match = rep(1:T,each=S/T) 				# vector matching spatial locations to teeth
   meanop =  kronecker(diag(1,T),rep(1,S/T)/(S/T))  	# S by T matrix averaging the responses over the six sites of 1 tooth



   #Store MCMC output: (not including z,gamma, and rho)

   ymis.save = array(NA,c(runs,sum(yMISS)));  colnames(ymis.save) = 1:sum(yMISS)
   misspara.save = array(NA,c(runs,J+2)); colnames(misspara.save) = c("a","b1","b2","xi")

   u.save = array(NA,c(runs,S,J))
   beta.save = array(NA,c(runs,p,J));   colnames(beta.save) = colnames(X)
   alpha.save = array(NA,c(runs,q,J));  colnames(alpha.save) = colnames(W)
   
   eta.save = array(NA,c(runs,S))
   # nu.save = array(NA,runs)

   V.save = array(NA,c(runs,2)); colnames(V.save) = c("v12","v22")
   Omega.save = array(NA,c(runs,S*(S+1)/2))
   lambda.save = array(NA,runs)


   z.mean = array(0,c(S,J,N))
   gamma.mean = rep(0,N)
   tau2.mean = matrix(0,S,S)
   

   
   #INITIAL VALUES:

   if(is.null(initials$ymis)) 
	for(j in 1:J) y[,j,][is.na(y[,j,])] = mean(na.omit(as.vector(y[,j,]))) else y[yMISS] = initials$ymis
   Sigma = cov(t(matrix(y,S,J*N)))*(nu-2)/nu


   if(is.null(initials$misspara)) {
	a = qnorm(mean(delta)) 							# missingness intercept
   	b = rep(0,J) 						# J by 1 missingness regression coefficients
   	xi = ifelse(missing.type=='gev',log(2)-1,NA) 	# missingness skewness
   } else {
	a = initials$misspara[1]; b = initials$misspara[2:(J+1)]; xi = ifelse(missing.type=='gev',initials$misspara[J+2],NA);
   }


   u = ifelse(matrix(is.null(initials$u),S,J), apply(y,1:2,mean), initials$u)
									# S by J regression intercept matrix
   beta = ifelse(matrix(is.null(initials$beta),p,J), matrix(0,p,J), initials$beta)
							       	# p by J clinical coefficient matrix
   xbeta = t(beta) %*% X	

   alpha = ifelse(matrix(is.null(initials$alpha),q,J), matrix(0,q,J), initials$alpha)
									# q by J spatial coefficient matrix
   if(is.null(W)) walpha = matrix(0,S,J) else walpha = W%*%alpha		

   
   z = ifelse(array(is.null(initials$z),c(S,J,N)), array(0,c(S,J,N)), initials$z)
									# S by J by N latent continuous variables for skew-t distribution
   gamma = ifelse(rep(is.null(initials$gamma),N), rep(1,N), initials$gamma)
									# latent parameter for df
   eta = ifelse(rep(is.null(initials$eta),S), rep(0,S), initials$eta)
							 		# skewness parameters
   # nu = 40	 					# degree of freedom of t distribution


   if(is.null(initials$V)) {
	V = cov(t(matrix(aperm(y,c(2,1,3)),J,S*N))); V=V/V[1,1];			# J by J across-response covariance
   } else V = initials$V;
   Vinv = solve(V) 
   dzv = sapply(alply(z,3),function(x) diag(eta)%*%x%*% sqrtm(V), simplify='array')

   Omega = ifelse(matrix(is.null(initials$Omega),S,S), solve(0.9*Sigma+0.1*diag(rep(1,S))), initials$Omega)
									# S by S across-spatial covariance
   lambda = ifelse(is.null(initials$lambda),1,initials$lambda)
									# graphical lasso shrinkage parameter
   tau2 = ifelse(matrix(is.null(initials$tau2),S,S), matrix(0.5,S,S), initials$tau2)
									# matrix of latent lasso shrinkage parameters




   # MCMC interations for collecting data
   for(iter in 1:(runs*thin+burn)) {


	## UPDATE MISSING OBSERVATIONS

	U = replicate(N,u) + replicate(N,walpha) + aperm(replicate(S,xbeta),c(3,1,2)) + dzv

if(TRUE)
	y[yMISS] = ymis.update(N,J,y,yMISS,delta,ST.match,missing.type,a,b,xi,U,V,Omega,gamma)	#debugged



	## UPDATE MISSING PARAMETERS

	ybar = sapply(alply(y,3),function(x) t(meanop)%*%x, simplify='array')  # T by J by N array of averaged responses across 6 sites

if(TRUE)
	a = a.update(c,ab.step,ybar,delta,missing.type,a,b,xi)	#debugged

if(TRUE)
	b = b.update(c,ab.step,ybar,delta,missing.type,a,b,xi)	#debugged

if(TRUE)
	if(missing.type=='gev')		
		xi = xi.update(xi.step,ybar,delta,a,b,xi)			#debugged



	## UPDATE REGRESSION INTERCEPT AND COEFFICIENTS

if(TRUE)
	u = u.update(c,S,J,N,gamma,Vinv,Omega,y,walpha,xbeta,dzv)		#debugged

if(!is.null(W)) {
	alpha = alpha.update(c,q,S,J,N,gamma,Vinv,Omega,y,u,W,xbeta,dzv)	#debugged
	walpha = W%*%alpha
    }

if(TRUE)
	beta = beta.update(c,p,S,J,N,gamma,Vinv,Omega,y,u,walpha,XX,dzv)	#debugged
	xbeta = t(beta) %*% X


	# update the constant to be used in the remaining of the loop
	A = y - replicate(N,u) - replicate(N,walpha) - aperm(replicate(S,xbeta),c(3,1,2)) 



	## UPDATE MVST PARAMETERS

if(TRUE)
while(TRUE) {	
	z = try(z.update(N,S,J,nu,A,Vinv,Omega,eta),TRUE)					#debugged
	if(any(is.na(z))) cat('NA of z generated at iteration', iter,'\n') else
	if(inherits(z,"try-error")) cat('Error in z sampling at iteration', iter,'\n') else break
	}

if(TRUE)
	eta = eta.update(N,S,Psi,gamma,z,Omega,A,Vinv)		#debugged

if(TRUE)
	V = V.update(N,S,J,V,A,eta,z,gamma,Omega,V.step)	#debugged
	Vinv = solve(V); Vsqrt = sqrtm(V);
	dzv = sapply(alply(z,3),function(x) diag(eta)%*%x%*% Vsqrt, simplify='array')


if(TRUE)
	gamma = gamma.update(N,S,J,nu,z,Omega,Vinv,A,dzv)		#debugged

#	nu = nu.update(gamma,nu,nu.step,nu.prior)			#debugged




	## UPDATE GRAPHICAL MODELS

	Tau = apply(mapply(function(x1,x2,x3) x1*(x2-x3)%*%Vinv%*%t(x2-x3), gamma,alply(A,3),alply(dzv,3),SIMPLIFY='array'),1:2,sum)
if(TRUE) 
	Omega = Omega.update.cv(N,J,S,Omega,Tau,lambda,tau2)
	
if(TRUE)	
	lambda = lambda.update.cv(Omega,lambda.prior)

if(TRUE)
	tau2 = tau2.update.cv(S,lambda,Omega)
	


      ##Keep track of MCMC output:
      if(iter>burn & (iter-burn)%%thin==0){
		ii = (iter-burn)/thin

		ymis.save[ii,] = y[yMISS]
		misspara.save[ii,] = c(a,b,xi)

		u.save[ii,,] = u
		beta.save[ii,,] = beta
   		alpha.save[ii,,] = alpha  
   
   		eta.save[ii,] = eta
   		# nu.save[ii] = nu

   		V.save[ii,] = V[,2]
   		Omega.save[ii,] = Omega[upper.tri(Omega,diag=TRUE)]
  		lambda.save[ii] = lambda

		z.mean = z.mean+z/runs
		gamma.mean = gamma.mean+gamma/runs
		tau2.mean = tau2.mean+tau2/runs

      }
	if(iter %% update ==0) cat(iter,'\n')


   }  # end of MCMC interaction


   if(is.null(W)) {
       res = list(ymis.save,misspara.save,u.save,beta.save,eta.save,V.save,Omega.save,lambda.save,nu);
       names(res) = c('ymis','misspara','u','beta','eta','V','Omega','lambda','nu')
   } else{
          res = list(ymis.save,misspara.save,u.save,beta.save,alpha.save,eta.save,V.save,Omega.save,lambda.save,nu);
          names(res) = c('ymis','misspara','u','beta','alpha','eta','V','Omega','lambda','nu')
   }
return(res)  

}	# end of function


