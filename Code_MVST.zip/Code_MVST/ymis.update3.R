# function to update the missing responses
ymis.update = function(N,J,y,yMISS,delta,ST.match,missing.type,a,b,xi,U,V,Omega,gamma){

   tmp = kronecker(V,solve(Omega))
   meanop1 = kronecker(diag(1,J),rep(1/6,6))			# average over 6 locations within a tooth

   # y.miss_prop = foreach(i = 1:N,.packages=c('plyr','mvtnorm','fExtremes','abind')) %dopar% { 	# loop for each subject i
   y.miss_prop = foreach(i = 1:N,.export=c('alply','dmvnorm','pgev','abind')) %dopar% {	
    if(sum(delta[,i])>0){		

	t.miss = which(delta[,i]==1)		# find the missing teeth
	yi.miss_new = rep(list(NA),length(t.miss))

	for(tt in 1:length(t.miss)) {
		t = t.miss[tt]
		yi.miss = rep(ST.match==t,J)  # corresponding missing index for responses of subject i

		Ui = c(U[,,i])				
		SIGMAi = tmp/gamma[i]	

		
		tmp2 = solve(SIGMAi[!yi.miss,!yi.miss])
		mean.ymis = Ui[yi.miss] + SIGMAi[yi.miss,!yi.miss]%*%tmp2%*%(y[,,i][!yi.miss]-Ui[!yi.miss])
		SIGMA.ymis = SIGMAi[yi.miss,yi.miss] - SIGMAi[yi.miss,!yi.miss]%*%tmp2%*%SIGMAi[!yi.miss,yi.miss]


		#rate.accept = 0
		#while(runif(1)>rate.accept) {


		# generate sample from multiple-try MH sampler
		K = 100; pp = sum(yi.miss)
		yi.miss.curr = y[,,i][yi.miss]
		yi.tmp.prop = matrix(rnorm(K*pp),K,pp)%*%chol(SIGMA.ymis)/2 + matrix(yi.miss.curr,K,pp,byrow=T)		# 6xJ vector

		if(missing.type=='probit') 
			log.wt.prop = sapply(alply(yi.tmp.prop,1),function(x) dmvnorm(x,mean=mean.ymis,sigma=SIGMA.ymis,log=TRUE)+ log(pnorm(a + x%*%meanop1%*%b)))
		if(missing.type=='gev') 
			log.wt.prop = sapply(alply(yi.tmp.prop,1),function(x) dmvnorm(x,mean=mean.ymis,sigma=SIGMA.ymis,log=TRUE)+ log(pgev(a + x%*%meanop1%*%b,xi)))	


		yi.miss.prop = yi.tmp.prop[sample(1:K,1,prob=exp(log.wt.prop-max(log.wt.prop))),]
		yi.tmp.curr = abind(matrix(rnorm((K-1)*pp),K-1,pp)%*%chol(SIGMA.ymis)/2 + matrix(yi.miss.prop,K-1,pp,byrow=T),yi.miss.curr,along=1)

		if(missing.type=='probit') 
			log.wt.curr = sapply(alply(yi.tmp.curr,1),function(x) dmvnorm(x,mean=mean.ymis,sigma=SIGMA.ymis,log=TRUE)+log(pnorm(a + x%*%meanop1%*%b)))
		if(missing.type=='gev') 
			log.wt.curr = sapply(alply(yi.tmp.curr,1),function(x) dmvnorm(x,mean=mean.ymis,sigma=SIGMA.ymis,log=TRUE)+log(pgev(a + x%*%meanop1%*%b,xi)))			
	

		
		rate.accept = sum(exp(log.wt.prop-max(log.wt.curr)))/sum(exp(log.wt.curr-max(log.wt.curr)))

		if(runif(1)<rate.accept) 
		   yi.miss_new[[tt]] = yi.miss.prop else yi.miss_new[[tt]] = yi.miss.curr



	}   # end of missing t loop

	yi.miss_new		# return the result for each subject i

    }  # end of if condition 

   } # end of subject loop



   # fill in y with the new missing values

   for(i in 1:N) { if(any(delta[,i]==1)) for(tt in 1:sum(delta[,i]==1)){
	t = which(delta[,i]==1)[tt]
	yit.miss = rep(ST.match==t,J)
	y[,,i][yit.miss] = y.miss_prop[[i]][[tt]]

   } }

   return(y[yMISS])

}